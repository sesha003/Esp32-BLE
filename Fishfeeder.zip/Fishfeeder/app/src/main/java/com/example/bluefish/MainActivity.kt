package com.example.bluefish

import android.Manifest
import android.annotation.SuppressLint
import android.app.TimePickerDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.BlueFish.R
import com.example.BlueFish.databinding.ActivityMainBinding
import java.util.Calendar
import java.util.Locale
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var bluetoothGatt: BluetoothGatt? = null
    private lateinit var binding: ActivityMainBinding
    private lateinit var enableBluetoothLauncher: ActivityResultLauncher<Intent>

    companion object {
        private const val REQUEST_ENABLE_BT = 1001
        private const val REQUEST_BLUETOOTH_CONNECT = 1
        private val YOUR_SERVICE_UUID = UUID.fromString("12345678-1234-5678-1234-56789ABCDEF0")
        private val YOUR_CHARACTERISTIC_UUID = UUID.fromString("87654321-4321-6789-4321-FEDCBA987654")
        private val FEED_NOW_COMMAND = "FeedNowCommand".toByteArray()
    }

    @RequiresApi(Build.VERSION_CODES.S)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        registerBluetoothLauncher()

        if (!bluetoothAdapter.isEnabled) {
            promptForBluetooth()
        }

        setupListeners()
    }

    private fun registerBluetoothLauncher() {
        enableBluetoothLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                Toast.makeText(this, "Bluetooth enabled", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to enable Bluetooth", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun promptForBluetooth() {
        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        enableBluetoothLauncher.launch(enableBtIntent)
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun setupListeners() {
        binding.btnBluetooth.setOnClickListener {
            if (hasAllPermissions()) {
                connectToESP32()
            } else {
                requestNeededPermissions()
            }
        }

        binding.btnReset.setOnClickListener { resetSchedules() }
        binding.btnFeedNow.setOnClickListener { sendFeedNowCommand() }

        binding.btnSchedule1.setOnClickListener { showTimePickerDialog(binding.schedule1Time) }
        binding.btnSchedule2.setOnClickListener { showTimePickerDialog(binding.schedule2Time) }
        binding.btnSchedule3.setOnClickListener { showTimePickerDialog(binding.schedule3Time) }

        // Handling "Schedule per day" interactions
        binding.btnSchedulePerDay.setOnClickListener { showScheduleOptionsDialog() }
    }

    private fun hasAllPermissions(): Boolean = ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun connectToESP32() {
        val deviceAddress = "10:06:1C:B4:F2:A8"
        val device = bluetoothAdapter.getRemoteDevice(deviceAddress)
        bluetoothGatt = device.connectGatt(this, false, gattCallback)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @RequiresApi(Build.VERSION_CODES.S)
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            runOnUiThread {
                when (newState) {
                    BluetoothGatt.STATE_CONNECTED -> {
                        Toast.makeText(this@MainActivity, "Connected to ESP32", Toast.LENGTH_SHORT).show()
                        if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_BLUETOOTH_CONNECT)
                            return@runOnUiThread // Correctly label this return to point to runOnUiThread
                        }
                        gatt?.discoverServices()
                    }
                    BluetoothGatt.STATE_DISCONNECTED -> {
                        Toast.makeText(this@MainActivity, "Disconnected from ESP32", Toast.LENGTH_SHORT).show()
                        bluetoothGatt?.close()
                    }
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val service = gatt?.getService(YOUR_SERVICE_UUID)
                service?.getCharacteristic(YOUR_CHARACTERISTIC_UUID)
            }
        }
    }


    private fun showTimePickerDialog(timeTextView: TextView) {
        val now = Calendar.getInstance()
        TimePickerDialog(this, { _, hourOfDay, minute ->
            val amPm = if (hourOfDay >= 12) "PM" else "AM"
            val formattedHour = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
            timeTextView.text = String.format(Locale.getDefault(), "%02d:%02d %s", formattedHour, minute, amPm)
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
    }

    private fun showScheduleOptionsDialog() {
        val options = arrayOf("Schedule 1", "Schedule 2", "Schedule 3")
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Choose a schedule")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> showTimePickerDialog(binding.schedule1Time)
                1 -> showTimePickerDialog(binding.schedule2Time)
                2 -> showTimePickerDialog(binding.schedule3Time)
            }
        }
        builder.show()
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun sendFeedNowCommand() {
        bluetoothGatt?.let { gatt ->
            val service = gatt.getService(YOUR_SERVICE_UUID)
            val characteristic = service?.getCharacteristic(YOUR_CHARACTERISTIC_UUID)
            if (characteristic != null) {
                characteristic.value = FEED_NOW_COMMAND
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                    val writeResult = gatt.writeCharacteristic(characteristic)
                    if (!writeResult) {
                        Toast.makeText(this, "Failed to send feed command", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Feed command sent", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_BLUETOOTH_CONNECT)
                }
            } else {
                Toast.makeText(this, "Characteristic not found", Toast.LENGTH_SHORT).show()
            }
        } ?: run {
            Toast.makeText(this, "Not connected to device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetSchedules() {
        binding.schedule1Time.text = getString(R.string.set_time)
        binding.schedule2Time.text = getString(R.string.set_time)
        binding.schedule3Time.text = getString(R.string.set_time)
        Toast.makeText(this, "Schedules reset", Toast.LENGTH_SHORT).show()
    }

    private fun requestNeededPermissions() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_BLUETOOTH_CONNECT)
    }
}
